# 网易云音乐 · Qt 桌面客户端

基于 Qt Quick/QML 的网易云音乐桌面客户端。推荐页提供推荐歌单、榜单精选、新歌新碟，精选页提供可筛选的歌单广场、排行榜、新歌和新碟，搜索按歌曲返回结果，底部播放栏支持暂停、切歌、拖动进度、音量、输出设备和播放队列。推荐区可直接播放整张歌单。

## 启动

需要 Qt 6.9+（Quick、Quick Controls 2、Network 和 Multimedia）、CMake、Ninja、Node.js 22+ 以及 pnpm。建议安装 Qt Image Formats 以解码 WebP 封面。首次运行前，在本目录执行：

```bash
pnpm --dir ../api-enhanced install --frozen-lockfile --prod --ignore-scripts
qt-cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/record-room
```

可以在 Qt Creator 中打开 `CMakeLists.txt`。客户端默认在随机端口管理一个仅监听回环地址的 API 子进程，并随窗口退出关闭。若要使用现成的 API 服务，可以在启动前设置 `NCM_API_URL`。自定义 API 地址用于公开曲库。扫码登录由内置 API 服务管理，扫码确认后同步账号歌单与个人栏目。未登录时可以浏览公开曲库，歌曲以接口实际返回的可播放地址为准。
