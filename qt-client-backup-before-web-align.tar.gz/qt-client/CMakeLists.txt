cmake_minimum_required(VERSION 3.21)
project(RecordRoom VERSION 0.1.0 LANGUAGES CXX)

find_package(Qt6 6.9 REQUIRED COMPONENTS Quick QuickControls2 Network Multimedia)
qt_standard_project_setup(REQUIRES 6.9)

set(NCM_API_REPOSITORY "${CMAKE_CURRENT_SOURCE_DIR}/../api-enhanced"
    CACHE PATH "Path to the api-enhanced checkout")

qt_add_executable(record-room
    src/main.cpp
    src/Library.cpp
    src/Library.h
    src/AudioCache.cpp
    src/AudioCache.h
    src/AudioStream.cpp
    src/AudioStream.h
)
target_include_directories(record-room PRIVATE src)
target_compile_features(record-room PRIVATE cxx_std_17)
target_compile_definitions(record-room PRIVATE NCM_API_REPOSITORY="${NCM_API_REPOSITORY}")
target_link_libraries(record-room PRIVATE
    Qt6::Quick Qt6::QuickControls2 Qt6::Network Qt6::Multimedia
)

configure_file(backend.cjs backend.cjs COPYONLY)
qt_add_resources(record-room branding
    PREFIX "/branding"
    FILES assets/netease-music.png
)
set_source_files_properties(qml/Theme.qml PROPERTIES QT_QML_SINGLETON_TYPE TRUE)
qt_add_qml_module(record-room
    URI RecordRoom
    QML_FILES
        qml/Main.qml
        qml/WindowResize.qml
        qml/Theme.qml
        qml/Symbol.qml
        qml/IconButton.qml
        qml/Cover.qml
        qml/StatusView.qml
        qml/DiscoverPage.qml
        qml/CollectionGrid.qml
        qml/RankingStrip.qml
        qml/HomeShelves.qml
        qml/TrackList.qml
        qml/VinylArt.qml
        qml/PlayerBar.qml
        qml/NowPlayingPage.qml
        qml/Sidebar.qml
        qml/BrowsePage.qml
        qml/LoginDialog.qml
)
