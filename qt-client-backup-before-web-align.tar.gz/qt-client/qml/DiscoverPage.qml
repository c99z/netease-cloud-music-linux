pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtMultimedia

ScrollView {
    id: page
    required property Library library
    signal choosePlaylist(var playlist, bool playNow)
    signal navigate(string key)
    property bool showAlbums: false
    readonly property var dailyCard: ({
        kind: "daily", title: "每日推荐",
        description: library.loggedIn ? "为你更新的歌曲" : "登录后查看"
    })
    property var featured: library.recommendations.length > 0 ? library.recommendations[0] : null
    clip: true
    contentWidth: availableWidth
    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff

    ColumnLayout {
        width: Math.max(0, page.availableWidth - 64)
        x: 32
        spacing: 16

        RowLayout {
            Layout.fillWidth: true
            Label {
                Layout.fillWidth: true
                text: "推荐"
                color: Theme.text
                font.pixelSize: 32
                font.weight: Font.Bold
            }
            IconButton {
                symbol: "refresh"
                text: "刷新发现页"
                enabled: !page.library.discoveryBusy
                onClicked: page.library.refreshDiscovery()
            }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 12
            Rectangle {
                id: hero
                Layout.fillWidth: true
                Layout.minimumWidth: 260
                Layout.preferredWidth: 660
                Layout.preferredHeight: 174
                radius: 20
                clip: true
                color: "#482631"
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: "#422631" }
                    GradientStop { position: .58; color: "#622e43" }
                    GradientStop { position: 1; color: "#7a3c4c" }
                }
                border.color: "#925361"

                VinylArt {
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.bottom: parent.bottom
                    width: parent.width * .42
                    coverSource: page.featured ? page.featured.art : ""
                }

                ColumnLayout {
                    anchors.left: parent.left
                    anchors.leftMargin: 22
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width * .61 - 21
                    spacing: 9
                    Label {
                        text: "推荐歌单"
                        color: "#ffd0d1"
                        font.pixelSize: 13
                        font.weight: Font.DemiBold
                    }
                    Label {
                        Layout.fillWidth: true
                        text: page.featured ? page.featured.title : "从一张唱片开始"
                        color: "#fff9f5"
                        font.pixelSize: Math.max(19, Math.min(27, hero.width / 27))
                        font.weight: Font.Bold
                        wrapMode: Text.Wrap
                        maximumLineCount: 2
                        elide: Text.ElideRight
                    }
                    Label {
                        Layout.fillWidth: true
                        text: page.featured ? (page.featured.description || page.featured.trackCount + " 首歌曲")
                                            : page.library.discoveryBusy ? "正在加载歌单…" : "发现歌单和新歌"
                        color: "#f1c8cd"
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }
                    RowLayout {
                        spacing: 8
                        Layout.topMargin: 5
                        visible: !!page.featured
                        Button {
                            id: showFeatured
                            text: "播放推荐歌单"
                            onClicked: page.choosePlaylist(page.featured, true)
                            palette.buttonText: Theme.ink
                            font.weight: Font.DemiBold
                            background: Rectangle {
                                implicitWidth: 120
                                implicitHeight: 36
                                radius: 9
                                color: showFeatured.hovered ? "#ffb0af" : Theme.accent
                                border.color: showFeatured.activeFocus ? Theme.ink : "transparent"
                            }
                        }
                        Button {
                            id: openFeatured
                            visible: hero.width >= 445
                            text: "查看歌单"
                            onClicked: page.choosePlaylist(page.featured, false)
                            palette.buttonText: Theme.text
                            background: Rectangle {
                                implicitWidth: 84
                                implicitHeight: 36
                                radius: 9
                                color: openFeatured.hovered ? "#885363" : "#613945"
                                border.color: openFeatured.activeFocus ? Theme.text : "transparent"
                            }
                        }
                    }
                }
            }
            ColumnLayout {
                Layout.preferredWidth: page.availableWidth > 900 ? 204 : 143
                Layout.fillWidth: false
                Layout.fillHeight: true
                spacing: 8
                SectionShortcut {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    text: "私人漫游"
                    glyph: "disc"
                    onClicked: page.navigate("roam")
                }
                SectionShortcut {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    text: "我喜欢的音乐"
                    glyph: "heart"
                    onClicked: page.navigate("liked")
                }
                SectionShortcut {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    text: "场景歌单"
                    glyph: "collection"
                    onClicked: page.navigate("sceneTags")
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            Label {
                Layout.fillWidth: true
                text: "推荐歌单"
                color: Theme.text
                font.pixelSize: 21
                font.weight: Font.Bold
            }
            SectionLink {
                text: "更多歌单"
                onClicked: page.navigate("featured")
            }
        }

        CollectionGrid {
            Layout.fillWidth: true
            entries: [page.dailyCard].concat(page.library.recommendations)
            onChosen: (entry) => {
                if (entry.kind === "daily")
                    page.navigate("daily")
                else
                    page.choosePlaylist(entry, false)
            }
        }

        RowLayout {
            Layout.fillWidth: true
            Label {
                Layout.fillWidth: true
                text: "榜单精选"
                color: Theme.text
                font.pixelSize: 21
                font.weight: Font.Bold
            }
            SectionLink {
                text: "全部榜单"
                onClicked: page.navigate("charts")
            }
        }

        RankingStrip {
            Layout.fillWidth: true
            visible: charts.length > 0
            charts: page.library.featuredCharts
            onChosen: (entry) => page.choosePlaylist(entry, false)
        }

        HomeShelves {
            Layout.fillWidth: true
            visible: shelves.length > 0
            shelves: page.library.homeShelves
            onCollectionChosen: (entry) => page.choosePlaylist(entry, false)
            onTracksChosen: (tracks, index) => {
                if (index < 0)
                    page.library.playAll(tracks)
                else
                    page.library.playCollection(tracks, index)
            }
        }

        StatusView {
            Layout.fillWidth: true
            visible: page.library.discoveryError.length > 0
                     || (page.library.recommendations.length === 0 && page.library.featuredCharts.length === 0)
            busy: page.library.discoveryBusy
            title: busy ? "正在加载发现页" : page.library.discoveryError.length ? "部分音乐暂无法加载" : "暂无推荐"
            detail: page.library.discoveryError
            actionText: busy ? "" : "重试"
            onAction: page.library.refreshDiscovery()
        }

        ColumnLayout {
            Layout.fillWidth: true
            visible: page.library.freshTracks.length > 0 || page.library.newAlbums.length > 0
            spacing: 10
            RowLayout {
                Layout.fillWidth: true
                Label {
                    Layout.fillWidth: true
                    text: "新歌新碟"
                    color: Theme.text
                    font.pixelSize: 21
                    font.weight: Font.Bold
                }
                SectionLink {
                    text: "新歌"
                    selected: !page.showAlbums
                    onClicked: page.showAlbums = false
                }
                SectionLink {
                    text: "新碟"
                    selected: page.showAlbums
                    onClicked: page.showAlbums = true
                }
                SectionLink {
                    text: "查看更多"
                    onClicked: page.navigate(page.showAlbums ? "albums" : "newTracks")
                }
            }
            TrackList {
                Layout.fillWidth: true
                Layout.preferredHeight: 36 + tracks.length * 59
                visible: !page.showAlbums
                interactive: false
                tracks: page.library.freshTracks.slice(0, 6)
                currentId: page.library.currentTrack.id || ""
                playing: page.library.media.playbackState === MediaPlayer.PlayingState
                onActivated: (index) => page.library.playCollection(page.library.freshTracks, index)
            }
            CollectionGrid {
                Layout.fillWidth: true
                visible: page.showAlbums
                entries: page.library.newAlbums
                onChosen: (entry) => page.choosePlaylist(entry, false)
            }
        }
        Item { Layout.preferredHeight: 8 }
    }

    component SectionLink: Button {
        id: link
        property bool selected: false
        palette.buttonText: link.selected ? Theme.text : Theme.secondary
        font.pixelSize: 12
        background: Rectangle {
            implicitWidth: 61
            implicitHeight: 30
            radius: 7
            color: link.selected ? Theme.accentSurface : link.hovered ? Theme.hover : Theme.panel
            border.color: link.activeFocus ? Theme.accent : Theme.line
        }
    }

    component SectionShortcut: AbstractButton {
        id: link
        required property string glyph
        padding: 10
        hoverEnabled: true
        focusPolicy: Qt.StrongFocus
        Accessible.name: text
        background: Rectangle {
            radius: 11
            color: link.hovered ? Theme.raised : Theme.panel
            border.color: link.activeFocus ? Theme.accent : Theme.line
        }
        contentItem: RowLayout {
            spacing: 9
            Symbol {
                Layout.preferredWidth: 18
                Layout.preferredHeight: 18
                name: link.glyph
                tint: Theme.accent
            }
            Label {
                Layout.fillWidth: true
                text: link.text
                color: Theme.text
                font.pixelSize: 12
                font.weight: Font.DemiBold
                elide: Text.ElideRight
            }
            Symbol {
                Layout.preferredWidth: 13
                Layout.preferredHeight: 13
                name: "chevron"
            }
        }
    }
}
