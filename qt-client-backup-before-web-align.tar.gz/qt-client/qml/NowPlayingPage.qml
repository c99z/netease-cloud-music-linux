pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ColumnLayout {
    id: page
    required property Library library
    signal closeRequested()

    readonly property var track: library.currentTrack
    readonly property var lines: library.lyrics
    readonly property int activeLine: lyricIndex(library.playbackPosition)
    property bool followLyrics: true
    spacing: 12

    function lyricIndex(position: real): int {
        if (!lines.length || lines[0].time < 0)
            return -1
        let low = 0
        let high = lines.length
        while (low < high) {
            const mid = Math.floor((low + high) / 2)
            if (lines[mid].time <= position)
                low = mid + 1
            else
                high = mid
        }
        return low - 1
    }

    function centerOnPlayback() {
        if (!visible || !followLyrics || !lyrics.count)
            return
        lyrics.positionViewAtIndex(Math.max(0, activeLine), ListView.Center)
    }

    onActiveLineChanged: Qt.callLater(centerOnPlayback)
    onLinesChanged: followLyrics = true
    onVisibleChanged: {
        if (visible) {
            followLyrics = true
            library.loadCurrentLyrics()
            Qt.callLater(centerOnPlayback)
        }
    }

    Connections {
        target: page.library
        enabled: page.visible
        function onQueueChanged() {
            page.library.loadCurrentLyrics()
        }
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 8
        IconButton {
            symbol: "back"
            text: "返回上一页"
            onClicked: page.closeRequested()
        }
        Label {
            text: "正在播放"
            color: Theme.text
            font.pixelSize: 21
            font.weight: Font.DemiBold
        }
    }

    Rectangle {
        id: stage
        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.bottomMargin: 20
        radius: 16
        border.color: Theme.line
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0; color: Theme.accentSurface }
            GradientStop { position: 0.48; color: Theme.panel }
            GradientStop { position: 1; color: Theme.rail }
        }

        RowLayout {
            anchors.fill: parent
            anchors.margins: stage.width >= 700 ? 28 : 16
            spacing: stage.width >= 700 ? 32 : 16

            Item {
                id: albumPane
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.preferredWidth: stage.width * 0.42
                Layout.minimumWidth: 128

                Column {
                    anchors.centerIn: parent
                    width: parent.width
                    spacing: 8

                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: Math.min(parent.width, Math.max(106, albumPane.height - 142), 320)
                        height: width
                        radius: 13
                        color: Theme.hover
                        border.color: Theme.line
                        Cover {
                            anchors.fill: parent
                            anchors.margins: 4
                            edge: 9
                            source: page.track.art || ""
                        }
                    }
                    Label {
                        topPadding: 7
                        width: parent.width
                        text: page.track.title || ""
                        textFormat: Text.PlainText
                        horizontalAlignment: Text.AlignHCenter
                        color: Theme.text
                        font.pixelSize: stage.width >= 700 ? 26 : 20
                        font.weight: Font.Bold
                        elide: Text.ElideRight
                    }
                    Label {
                        width: parent.width
                        text: page.track.artist || ""
                        textFormat: Text.PlainText
                        horizontalAlignment: Text.AlignHCenter
                        color: Theme.secondary
                        font.pixelSize: 14
                        elide: Text.ElideRight
                    }
                    Label {
                        width: parent.width
                        text: page.track.album || ""
                        visible: text.length > 0
                        textFormat: Text.PlainText
                        horizontalAlignment: Text.AlignHCenter
                        color: Theme.muted
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }
                }
            }

            Rectangle {
                Layout.fillHeight: true
                Layout.preferredWidth: 1
                color: Theme.line
            }

            ColumnLayout {
                Layout.preferredWidth: stage.width * 0.53
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 10

                RowLayout {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 32
                    Label {
                        Layout.fillWidth: true
                        text: "歌词"
                        color: Theme.secondary
                        font.pixelSize: 14
                        font.weight: Font.DemiBold
                    }
                    Button {
                        id: followButton
                        text: "回到当前歌词"
                        visible: !page.followLyrics && page.activeLine >= 0
                        palette.buttonText: Theme.text
                        onClicked: {
                            page.followLyrics = true
                            page.centerOnPlayback()
                        }
                        background: Rectangle {
                            implicitHeight: 30
                            radius: 7
                            color: followButton.hovered ? Theme.hover : Theme.raised
                            border.color: followButton.activeFocus ? Theme.accent : Theme.line
                        }
                    }
                }

                ListView {
                    id: lyrics
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    visible: count > 0
                    model: page.lines
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    spacing: 2
                    onCountChanged: Qt.callLater(page.centerOnPlayback)
                    onMovementStarted: page.followLyrics = false
                    ScrollBar.vertical: ScrollBar {
                        onPressedChanged: {
                            if (pressed)
                                page.followLyrics = false
                        }
                    }
                    header: Item { height: Math.max(0, lyrics.height / 2 - 24) }
                    footer: Item { height: Math.max(0, lyrics.height / 2 - 24) }

                    delegate: AbstractButton {
                        id: lyric
                        required property int index
                        required property var modelData
                        readonly property bool activeLine: index === page.activeLine
                        readonly property bool canJump: modelData.time >= 0
                            && page.library.canSeekPlayback && !page.library.playbackBusy
                        width: Math.max(0, lyrics.width - 10)
                        padding: 10
                        hoverEnabled: true
                        focusPolicy: canJump ? Qt.StrongFocus : Qt.NoFocus
                        Accessible.name: modelData.text
                        Accessible.description: canJump ? "跳到 " + Theme.time(modelData.time) : ""
                        onClicked: {
                            if (canJump) {
                                page.followLyrics = true
                                page.library.seekPlayback(modelData.time)
                                Qt.callLater(page.centerOnPlayback)
                            }
                        }
                        background: Rectangle {
                            radius: 8
                            color: lyric.activeLine ? Theme.accentSurface
                                 : lyric.hovered && lyric.canJump ? Theme.hover : "transparent"
                            border.color: lyric.activeFocus ? Theme.accent : "transparent"
                        }
                        contentItem: ColumnLayout {
                            spacing: 4
                            Label {
                                Layout.fillWidth: true
                                text: lyric.modelData.text
                                textFormat: Text.PlainText
                                wrapMode: Text.Wrap
                                color: lyric.activeLine ? Theme.text : Theme.secondary
                                font.pixelSize: stage.width >= 700 ? 17 : 14
                                font.weight: lyric.activeLine ? Font.DemiBold : Font.Normal
                            }
                            Label {
                                Layout.fillWidth: true
                                visible: text.length > 0
                                text: lyric.modelData.translation
                                textFormat: Text.PlainText
                                wrapMode: Text.Wrap
                                color: lyric.activeLine ? Theme.accent : Theme.muted
                                font.pixelSize: 13
                            }
                        }
                    }
                }

                Item {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    visible: lyrics.count === 0
                    StatusView {
                        anchors.centerIn: parent
                        width: Math.min(parent.width, 360)
                        symbol: "music"
                        busy: page.library.lyricsBusy
                        title: busy ? "正在加载歌词…" : page.library.lyricsError.length ? "歌词加载失败" : "暂无歌词"
                        actionText: !busy && page.library.lyricsError.length ? "重试" : ""
                        onAction: page.library.loadCurrentLyrics(true)
                    }
                }
            }
        }
    }
}
