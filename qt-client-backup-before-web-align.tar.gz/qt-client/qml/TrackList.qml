pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ListView {
    id: list
    required property var tracks
    property string currentId
    property bool playing: false
    signal activated(int index)
    model: tracks
    clip: true
    reuseItems: true
    boundsBehavior: Flickable.StopAtBounds
    spacing: 2
    ScrollBar.vertical: ScrollBar { policy: list.interactive ? ScrollBar.AsNeeded : ScrollBar.AlwaysOff }

    header: RowLayout {
        width: list.width - 14
        height: 36
        spacing: 10
        Label {
            Layout.preferredWidth: 34
            text: "#"
            color: Theme.muted
            horizontalAlignment: Text.AlignHCenter
            font.pixelSize: 12
        }
        Label {
            Layout.fillWidth: true
            Layout.preferredWidth: 300
            text: "歌曲"
            color: Theme.muted
            font.pixelSize: 12
        }
        Label {
            Layout.fillWidth: true
            Layout.preferredWidth: 170
            visible: list.width > 570
            text: "专辑"
            color: Theme.muted
            font.pixelSize: 12
        }
        Label {
            Layout.preferredWidth: 68
            text: "时长"
            horizontalAlignment: Text.AlignRight
            color: Theme.muted
            font.pixelSize: 12
        }
    }

    delegate: AbstractButton {
        id: row
        required property int index
        required property var modelData
        readonly property bool isCurrent: modelData.id === list.currentId
        width: list.width - 10
        height: 57
        hoverEnabled: true
        focusPolicy: Qt.StrongFocus
        Accessible.name: modelData.title + "，" + modelData.artist
        onClicked: list.activated(index)

        background: Rectangle {
            radius: 9
            color: row.isCurrent ? Theme.accentSurface
                                 : row.hovered || row.activeFocus ? Theme.raised : "transparent"
            border.width: row.activeFocus ? 1 : 0
            border.color: Theme.accent
        }

        contentItem: RowLayout {
            spacing: 10
            Item {
                Layout.preferredWidth: 34
                Layout.fillHeight: true
                Label {
                    anchors.centerIn: parent
                    visible: !row.hovered && !row.isCurrent
                    text: String(row.index + 1).padStart(2, "0")
                    color: Theme.muted
                    font.pixelSize: 12
                }
                Symbol {
                    anchors.centerIn: parent
                    width: 17
                    height: 17
                    visible: row.hovered || row.isCurrent
                    name: row.isCurrent && list.playing ? "music" : "play"
                    tint: row.isCurrent ? Theme.accent : Theme.text
                }
            }
            RowLayout {
                Layout.fillWidth: true
                Layout.preferredWidth: 300
                spacing: 11
                Cover {
                    Layout.preferredWidth: 40
                    Layout.preferredHeight: 40
                    source: row.modelData.art
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 0
                    Label {
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                        text: row.modelData.title
                        color: row.isCurrent ? Theme.accent : Theme.text
                        font.weight: Font.DemiBold
                        font.pixelSize: 13
                    }
                    Label {
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                        text: row.modelData.artist
                        color: Theme.secondary
                        font.pixelSize: 12
                    }
                }
            }
            Label {
                Layout.fillWidth: true
                Layout.preferredWidth: 170
                visible: list.width > 570
                text: row.modelData.album || "—"
                color: Theme.secondary
                elide: Text.ElideRight
                font.pixelSize: 12
            }
            Label {
                Layout.preferredWidth: 65
                text: Theme.time(row.modelData.duration)
                horizontalAlignment: Text.AlignRight
                color: Theme.muted
                font.pixelSize: 12
            }
            Item { Layout.preferredWidth: 3 }
        }
    }
}
