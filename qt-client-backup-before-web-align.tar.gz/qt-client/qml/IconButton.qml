import QtQuick
import QtQuick.Controls

AbstractButton {
    id: control
    required property string symbol
    property bool featured: false
    property bool selected: false
    property int iconSize: 18
    implicitWidth: featured ? 40 : 36
    implicitHeight: implicitWidth
    hoverEnabled: true
    focusPolicy: Qt.StrongFocus
    Accessible.name: text

    background: Rectangle {
        radius: control.featured ? width / 2 : 9
        color: {
            if (control.featured)
                return control.down ? "#ec6778" : control.hovered ? "#ffb0af" : Theme.accent
            if (control.selected)
                return Theme.accentSurface
            return control.hovered || control.activeFocus ? Theme.hover : "transparent"
        }
        border.width: control.activeFocus ? 1 : 0
        border.color: Theme.accent
        opacity: control.enabled ? 1 : 0.38
    }
    contentItem: Item {
        Symbol {
            anchors.centerIn: parent
            width: control.iconSize
            height: width
            name: control.symbol
            tint: control.featured ? Theme.ink : control.selected ? Theme.accent : Theme.text
            opacity: control.enabled ? 1 : 0.35
        }
    }
    ToolTip.visible: hovered && text.length > 0
    ToolTip.delay: 500
    ToolTip.text: text
}
