pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtMultimedia

ColumnLayout {
    id: page
    required property Library library
    signal playlistChosen(var data)
    signal loginRequested()
    signal postChosen(string author, string message)

    readonly property string sectionKey: library.section
    readonly property bool podcastPage: sectionKey.startsWith("podcast")
    readonly property bool recentPage: sectionKey.startsWith("recent")
    readonly property bool myPodcastPage: ["myPodcasts", "savedVoices", "createdVoices",
        "boughtVoices", "likedVoices", "myRecentVoices"].includes(sectionKey)
    readonly property bool vipPage: ["vip", "vipCharts", "vipSongs"].includes(sectionKey)
    readonly property bool collectionPage: ["collections", "savedAlbums", "savedArtists", "savedVideos"].includes(sectionKey)
    readonly property bool followingPage: ["following", "followingPeople"].includes(sectionKey)
    readonly property bool essentialChild: ["officialPlaylists", "newTracks", "albums", "essentialPodcasts"].includes(sectionKey)
    readonly property bool curated: essentialChild || vipPage || ["essential", "featured", "charts", "artists"].includes(sectionKey)
    readonly property string tabKey: essentialChild ? "essential" : vipPage ? "vip"
        : sectionKey === "podcastCategory" ? "podcastCategories" : sectionKey
    readonly property bool gallery: ["officialPlaylists", "artists", "featured", "albums", "savedAlbums", "podcasts", "podcastCategory", "vip", "scenePlaylists"].includes(sectionKey)
    readonly property var tabs: curated ? [
        { key: "essential", label: "精选" }, { key: "featured", label: "歌单广场" },
        { key: "charts", label: "排行榜" }, { key: "artists", label: "歌手" },
        { key: "vip", label: "VIP" }
    ] : podcastPage ? [
        { key: "podcasts", label: "推荐播客" }, { key: "podcastPrograms", label: "推荐节目" },
        { key: "podcastCategories", label: "分类" }, { key: "podcastTop", label: "热门榜" },
        { key: "podcastNew", label: "新晋榜" }
    ] : recentPage ? [
        { key: "recent", label: "歌曲" }, { key: "recentPlaylists", label: "歌单" },
        { key: "recentAlbums", label: "专辑" }, { key: "recentRadios", label: "播客" },
        { key: "recentVoices", label: "节目" }, { key: "recentVideos", label: "视频" }
    ] : myPodcastPage ? [
        { key: "myPodcasts", label: "已订阅" }, { key: "savedVoices", label: "收藏的播客" },
        { key: "createdVoices", label: "我创建的" }, { key: "boughtVoices", label: "我购买的" },
        { key: "likedVoices", label: "喜欢的声音" }, { key: "myRecentVoices", label: "最近收听" }
    ] : collectionPage ? [
        { key: "collections", label: "歌单" }, { key: "savedAlbums", label: "专辑" },
        { key: "savedArtists", label: "歌手" }, { key: "savedVideos", label: "视频" }
    ] : sectionKey === "scenePlaylists" ? [
        { key: "sceneTags", label: "选择场景" }
    ] : followingPage ? [
        { key: "following", label: "动态" }, { key: "followingPeople", label: "关注的人" }
    ] : []
    readonly property var areas: ["全部", "华语", "欧美", "日本", "韩国"]
    readonly property var titles: ({
        essential: "精选", officialPlaylists: "官方歌单", essentialPodcasts: "热门播客",
        featured: "歌单广场", charts: "排行榜", artists: "歌手", newTracks: "最新音乐", albums: "新碟", daily: "每日推荐",
        podcasts: "播客", roam: "漫游", following: "关注",
        liked: "我喜欢的音乐", recent: "最近播放", myPodcasts: "我的播客",
        collections: "我的收藏", created: "创建的歌单"
    })
    spacing: 12

    component SectionFilter: ComboBox {
        id: filter
        contentItem: Label {
            text: filter.displayText
            leftPadding: 12
            rightPadding: 25
            color: Theme.text
            verticalAlignment: Text.AlignVCenter
            font.pixelSize: 12
        }
        indicator: Symbol {
            anchors.right: parent.right
            anchors.rightMargin: 10
            anchors.verticalCenter: parent.verticalCenter
            width: 14
            height: 14
            name: "down"
        }
        background: Rectangle {
            implicitHeight: 33
            radius: 8
            color: Theme.panel
            border.color: filter.activeFocus ? Theme.accent : Theme.line
        }
        delegate: ItemDelegate {
            id: category
            required property string modelData
            width: filter.width
            text: modelData
            contentItem: Label {
                text: category.text
                color: Theme.text
                elide: Text.ElideRight
                font.pixelSize: 12
                verticalAlignment: Text.AlignVCenter
            }
            background: Rectangle {
                implicitHeight: 29
                color: category.hovered || category.highlighted ? Theme.hover : Theme.panel
            }
        }
        popup: Popup {
            y: filter.height + 3
            width: filter.width
            implicitHeight: Math.min(contentItem.implicitHeight + 8, 258)
            padding: 4
            background: Rectangle {
                radius: 8
                color: Theme.panel
                border.color: Theme.line
            }
            contentItem: ListView {
                clip: true
                implicitHeight: contentHeight
                model: filter.popup.visible ? filter.delegateModel : null
                currentIndex: filter.highlightedIndex
                ScrollBar.vertical: ScrollBar {}
            }
        }
    }

    RowLayout {
        Layout.fillWidth: true
        IconButton {
            symbol: "back"
            text: "回到精选"
            visible: page.essentialChild
            onClicked: page.library.browse("essential")
        }
        Label {
            Layout.fillWidth: true
            text: page.sectionKey === "sceneTags" ? "场景歌单"
                : page.sectionKey === "scenePlaylists" ? page.library.sceneName
                : page.sectionKey === "podcastCategory" ? page.library.podcastCategoryName
                : page.podcastPage ? "播客" : page.recentPage ? "最近播放"
                : page.myPodcastPage ? "我的播客" : page.collectionPage ? "我的收藏"
                : page.followingPage ? "关注" : page.vipPage ? "会员精选" : page.titles[page.sectionKey] || ""
            color: Theme.text
            font.pixelSize: 30
            font.weight: Font.Bold
        }
        Button {
            id: playList
            visible: page.library.sectionTracks.length > 0
            text: page.sectionKey === "roam" ? "开始漫游" : "播放全部"
            palette.buttonText: Theme.ink
            onClicked: page.library.playSection(0)
            background: Rectangle {
                implicitWidth: 92
                implicitHeight: 34
                radius: 8
                color: playList.hovered ? "#ffb0af" : Theme.accent
                border.color: playList.activeFocus ? Theme.ink : "transparent"
            }
        }
        IconButton {
            symbol: "refresh"
            text: page.sectionKey === "roam" ? "换一组" : "刷新"
            visible: !page.library.sectionNeedsLogin
            enabled: !page.library.sectionBusy
            onClicked: page.library.browse(page.library.section)
        }
    }

    RowLayout {
        Layout.fillWidth: true
        visible: page.tabs.length > 0
        spacing: 7
        Repeater {
            model: page.tabs
            delegate: Button {
                id: tab
                required property var modelData
                readonly property bool selected: page.tabKey === modelData.key
                text: modelData.label
                palette.buttonText: Theme.text
                onClicked: {
                    if (page.sectionKey !== modelData.key || page.library.sectionError.length)
                        page.library.browse(modelData.key)
                }
                background: Rectangle {
                    implicitWidth: 70
                    implicitHeight: 33
                    radius: 8
                    color: tab.selected ? Theme.accentSurface : tab.hovered ? Theme.hover : Theme.panel
                    border.color: tab.selected || tab.activeFocus ? Theme.accent : Theme.line
                }
                contentItem: Label {
                    text: tab.text
                    color: tab.selected ? Theme.accent : Theme.secondary
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    font.pixelSize: 12
                }
            }
        }
        Item { Layout.fillWidth: true }
        SectionFilter {
            id: categoryBox
            Layout.preferredWidth: 145
            readonly property bool category: page.sectionKey === "featured"
            visible: category || page.sectionKey === "newTracks" || page.sectionKey === "albums" || page.sectionKey === "artists"
            model: category ? page.library.playlistCategories : page.areas
            currentIndex: category ? page.library.playlistCategories.indexOf(page.library.playlistCategory)
                : page.areas.indexOf(page.library.curatedArea)
            onActivated: (index) => {
                if (category)
                    page.library.selectPlaylistCategory(page.library.playlistCategories[index])
                else
                    page.library.selectCuratedArea(page.areas[index])
            }
            Accessible.name: category ? "歌单分类" : "地区"
        }
    }

    RowLayout {
        Layout.fillWidth: true
        visible: page.vipPage || page.sectionKey === "artists" || ["newTracks", "albums"].includes(page.sectionKey)
        spacing: 8
        Repeater {
            model: page.vipPage ? [
                { key: "vip", label: "会员歌单" }, { key: "vipCharts", label: "会员榜单" },
                { key: "vipSongs", label: "推荐歌曲" }
            ] : ["newTracks", "albums"].includes(page.sectionKey) ? [
                { key: "newTracks", label: "新歌" }, { key: "albums", label: "新碟" }
            ] : []
            delegate: Button {
                id: subTab
                required property var modelData
                text: modelData.label
                palette.buttonText: page.sectionKey === modelData.key ? Theme.accent : Theme.text
                onClicked: page.library.browse(modelData.key)
                background: Rectangle {
                    implicitHeight: 32
                    radius: 7
                    color: subTab.hovered ? Theme.hover : Theme.panel
                    border.color: page.sectionKey === subTab.modelData.key ? Theme.accent : Theme.line
                }
            }
        }
        SectionFilter {
            id: artistTypeBox
            visible: page.sectionKey === "artists"
            model: ["全部", "男歌手", "女歌手", "组合"]
            currentIndex: model.indexOf(page.library.artistType)
            onActivated: (index) => page.library.selectArtistType(model[index])
            Accessible.name: "歌手类型"
        }
        Item { Layout.fillWidth: true }
    }

    ScrollView {
        id: overview
        Layout.fillWidth: true
        Layout.fillHeight: true
        visible: page.sectionKey === "essential" && page.library.sectionShelves.length > 0
        clip: true
        contentWidth: availableWidth
        ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
        HomeShelves {
            width: overview.availableWidth - 10
            shelves: page.library.sectionShelves
            onCollectionChosen: (entry) => page.playlistChosen(entry)
            onSectionChosen: (section) => page.library.browse(section)
            onTracksChosen: (tracks, index) => {
                if (index < 0)
                    page.library.playAll(tracks)
                else
                    page.library.playCollection(tracks, index)
            }
        }
    }

    StatusView {
        Layout.fillWidth: true
        Layout.topMargin: 32
        visible: page.library.sectionBusy || page.library.sectionNeedsLogin
                 || (page.library.sectionItems.length === 0 && page.library.sectionTracks.length === 0
                     && page.library.sectionShelves.length === 0)
        busy: page.library.sectionBusy
        symbol: page.library.sectionNeedsLogin ? "user" : "disc"
        title: busy ? "正在加载…" : page.library.sectionNeedsLogin ? "登录后查看"
                : page.library.sectionError.length ? "暂时无法加载" : "暂无内容"
        detail: page.library.sectionError
        actionText: busy ? "" : page.library.sectionNeedsLogin ? "扫码登录"
                    : page.library.sectionError.length ? "重试" : ""
        onAction: {
            if (page.library.sectionNeedsLogin)
                page.loginRequested()
            else
                page.library.browse(page.library.section)
        }
    }

    TrackList {
        Layout.fillWidth: true
        Layout.fillHeight: true
        visible: tracks.length > 0
        tracks: page.library.sectionTracks
        currentId: page.library.currentTrack.id || ""
        playing: page.library.media.playbackState === MediaPlayer.PlayingState
        onActivated: (index) => {
            if (page.sectionKey === "roam")
                page.library.playSection(index)
            else
                page.library.playCollection(tracks, index)
        }
    }

    ScrollView {
        id: galleryView
        Layout.fillWidth: true
        Layout.fillHeight: true
        visible: page.gallery && page.library.sectionItems.length > 0
        contentWidth: availableWidth
        clip: true
        ScrollBar.horizontal.policy: ScrollBar.AlwaysOff

        CollectionGrid {
            width: galleryView.availableWidth - 10
            singleRow: false
            entries: page.gallery ? page.library.sectionItems : []
            onChosen: (data) => page.playlistChosen(data)
        }
    }

    ListView {
        id: entries
        Layout.fillWidth: true
        Layout.fillHeight: true
        visible: !page.gallery && count > 0
        clip: true
        reuseItems: true
        spacing: 6
        boundsBehavior: Flickable.StopAtBounds
        model: page.library.sectionItems
        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }
        delegate: AbstractButton {
            id: entry
            required property var modelData
            width: entries.width - 9
            height: 65
            padding: 8
            hoverEnabled: true
            focusPolicy: Qt.StrongFocus
            Accessible.name: modelData.displayTitle || modelData.title || ""
            background: Rectangle {
                radius: 10
                color: entry.hovered ? Theme.raised : Theme.panel
                border.color: entry.activeFocus ? Theme.accent : Theme.line
            }
            onClicked: {
                if (modelData.kind === "person") {
                    Qt.openUrlExternally("https://music.163.com/#/user/home?id=" + encodeURIComponent(modelData.id))
                } else if (modelData.kind === "podcastCategory") {
                    page.library.browsePodcastCategory(modelData)
                } else if (modelData.kind === "sceneCategory") {
                    page.library.browseSceneCategory(modelData)
                } else if (modelData.kind === "track") {
                    page.library.playAll([modelData])
                } else if (modelData.kind === "video") {
                    const path = /^[0-9]+$/.test(modelData.id) ? "mv" : "video"
                    Qt.openUrlExternally("https://music.163.com/#/" + path + "?id=" + encodeURIComponent(modelData.id))
                } else if (modelData.kind === "post") {
                    page.postChosen(modelData.displayTitle, modelData.subtitle)
                } else {
                    page.playlistChosen(modelData)
                }
            }
            contentItem: RowLayout {
                spacing: 11
                Cover {
                    Layout.preferredWidth: 46
                    Layout.preferredHeight: 46
                    source: entry.modelData.art
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Label {
                        Layout.fillWidth: true
                        text: entry.modelData.displayTitle || entry.modelData.title || ""
                        color: Theme.text
                        font.pixelSize: 13
                        font.weight: Font.DemiBold
                        elide: Text.ElideRight
                    }
                    Label {
                        Layout.fillWidth: true
                        textFormat: Text.PlainText
                        text: entry.modelData.subtitle || entry.modelData.description || (entry.modelData.trackCount
                              ? entry.modelData.trackCount + (entry.modelData.kind === "radio" ? " 期节目" : " 首歌曲") : "")
                        visible: text.length > 0
                        color: Theme.muted
                        font.pixelSize: 11
                        elide: Text.ElideRight
                    }
                }
                Symbol {
                    Layout.preferredWidth: 17
                    Layout.preferredHeight: 17
                    name: "chevron"
                }
            }
        }
    }
    Item {
        Layout.fillHeight: true
        visible: page.library.sectionItems.length === 0 && page.library.sectionTracks.length === 0
                     && page.library.sectionShelves.length === 0
    }
}
