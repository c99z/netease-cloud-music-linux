pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ColumnLayout {
    id: root
    required property var shelves
    signal collectionChosen(var item)
    signal sectionChosen(string section)
    signal tracksChosen(var tracks, int index)
    spacing: 20

    component Tag: Rectangle {
        id: tag
        required property string label
        implicitWidth: caption.implicitWidth + 10
        implicitHeight: 18
        radius: 4
        color: Theme.accentSurface
        Label {
            id: caption
            anchors.centerIn: parent
            text: tag.label
            color: Theme.accent
            font.pixelSize: 10
        }
    }

    Repeater {
        model: root.shelves
        delegate: ColumnLayout {
            id: shelf
            required property var modelData
            readonly property bool songs: modelData.kind === "tracks"
            readonly property string route: modelData.route || ""
            Layout.fillWidth: true
            spacing: 9

            RowLayout {
                Layout.fillWidth: true
                Label {
                    Layout.fillWidth: true
                    visible: !shelf.route
                    text: shelf.modelData.title
                    color: Theme.text
                    font.pixelSize: 21
                    font.weight: Font.Bold
                    elide: Text.ElideRight
                }
                AbstractButton {
                    id: sectionLink
                    visible: !!shelf.route
                    hoverEnabled: true
                    focusPolicy: Qt.StrongFocus
                    Accessible.name: shelf.modelData.title
                    onClicked: root.sectionChosen(shelf.route)
                    contentItem: RowLayout {
                        spacing: 6
                        Label {
                            text: shelf.modelData.title
                            color: sectionLink.hovered || sectionLink.activeFocus ? Theme.accent : Theme.text
                            font.pixelSize: 21
                            font.weight: Font.Bold
                        }
                        Symbol {
                            Layout.preferredWidth: 15
                            Layout.preferredHeight: 15
                            name: "chevron"
                        }
                    }
                }
                Item { Layout.fillWidth: true; visible: !!shelf.route }
                Button {
                    id: playShelf
                    visible: shelf.songs && !shelf.route
                    text: "播放全部"
                    palette.buttonText: Theme.text
                    font.pixelSize: 12
                    onClicked: root.tracksChosen(shelf.modelData.items, -1)
                    background: Rectangle {
                        implicitWidth: 82
                        implicitHeight: 31
                        radius: 8
                        color: playShelf.hovered ? Theme.hover : Theme.panel
                        border.color: playShelf.activeFocus ? Theme.accent : Theme.line
                    }
                }
            }

            CollectionGrid {
                Layout.fillWidth: true
                visible: shelf.modelData.kind === "playlists"
                entries: visible ? shelf.modelData.items : []
                singleRow: !!shelf.route
                minimumColumnWidth: shelf.route ? 214 : 146
                maximumCoverHeight: shelf.route ? 244 : 153
                showPlays: !!shelf.route
                onChosen: (entry) => root.collectionChosen(entry)
            }

            GridLayout {
                id: shelfGrid
                Layout.fillWidth: true
                visible: shelf.modelData.kind !== "playlists"
                columns: width >= 670 ? 2 : 1
                rowSpacing: 6
                columnSpacing: 15
                Repeater {
                    model: shelfGrid.visible ? shelf.modelData.items : []
                    delegate: AbstractButton {
                        id: row
                        required property int index
                        required property var modelData
                        Layout.fillWidth: true
                        Layout.preferredWidth: 1
                        Layout.preferredHeight: 67
                        padding: 7
                        hoverEnabled: true
                        focusPolicy: Qt.StrongFocus
                        Accessible.name: modelData.title
                        background: Rectangle {
                            radius: 8
                            color: row.hovered ? Theme.hover : Theme.panel
                            border.color: row.activeFocus ? Theme.accent : "transparent"
                        }
                        onClicked: {
                            if (shelf.songs)
                                root.tracksChosen(shelf.modelData.items, index)
                            else
                                root.collectionChosen(modelData)
                        }
                        contentItem: RowLayout {
                            spacing: 10
                            Cover {
                                Layout.preferredWidth: 50
                                Layout.preferredHeight: 50
                                source: row.modelData.art
                            }
                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 3
                                Label {
                                    Layout.fillWidth: true
                                    text: row.modelData.title
                                    color: Theme.text
                                    font.pixelSize: 13
                                    font.weight: Font.DemiBold
                                    elide: Text.ElideRight
                                }
                                RowLayout {
                                    Layout.fillWidth: true
                                    visible: shelf.songs
                                    spacing: 4
                                    Tag { label: "VIP"; visible: row.modelData.vip === true }
                                    Tag { label: "原唱"; visible: row.modelData.original === true }
                                    Tag { label: "SQ"; visible: row.modelData.sq === true }
                                    Tag {
                                        label: row.modelData.remark || ""
                                        visible: label.length > 0 && row.width > 280
                                    }
                                    Label {
                                        Layout.fillWidth: true
                                        text: row.modelData.artist || ""
                                        color: Theme.muted
                                        font.pixelSize: 11
                                        elide: Text.ElideRight
                                    }
                                }
                                Label {
                                    Layout.fillWidth: true
                                    visible: !shelf.songs
                                    text: row.modelData.description || ""
                                    color: Theme.muted
                                    font.pixelSize: 11
                                    elide: Text.ElideRight
                                }
                            }
                            Symbol {
                                Layout.preferredWidth: 15
                                Layout.preferredHeight: 15
                                name: shelf.songs ? "play" : "chevron"
                                tint: row.hovered ? Theme.accent : Theme.muted
                            }
                        }
                    }
                }
            }
        }
    }
}
