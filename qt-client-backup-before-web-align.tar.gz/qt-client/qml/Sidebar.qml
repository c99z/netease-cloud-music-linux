pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: rail
    required property Library library
    property string activeSection
    property string selectedPlaylist
    property bool showCreated: true
    property bool showSaved: true
    signal navigate(string key)
    signal playlistChosen(var playlist)
    signal loginRequested()
    signal createRequested()

    color: Theme.rail

    component NavRow: AbstractButton {
        id: nav
        required property string glyph
        property bool selected: false
        implicitHeight: 36
        hoverEnabled: true
        focusPolicy: Qt.StrongFocus
        Accessible.name: text
        background: Rectangle {
            radius: 8
            color: nav.selected ? Theme.accentSurface : nav.hovered ? Theme.hover : "transparent"
            border.width: nav.activeFocus ? 1 : 0
            border.color: Theme.accent
            Rectangle {
                anchors.left: parent.left
                anchors.verticalCenter: parent.verticalCenter
                width: 3
                height: 18
                radius: 1.5
                visible: nav.selected
                color: Theme.accent
            }
        }
        contentItem: RowLayout {
            spacing: 10
            Item { Layout.preferredWidth: 8 }
            Symbol {
                Layout.preferredWidth: 17
                Layout.preferredHeight: 17
                name: nav.glyph
                tint: nav.selected ? Theme.accent : Theme.secondary
            }
            Label {
                Layout.fillWidth: true
                text: nav.text
                color: nav.selected ? Theme.text : Theme.secondary
                font.pixelSize: 13
                font.weight: nav.selected ? Font.Bold : Font.Medium
                elide: Text.ElideRight
            }
            Item { Layout.preferredWidth: 7 }
        }
    }

    component PlaylistRow: AbstractButton {
        id: row
        required property var playlist
        property bool selected: false
        implicitHeight: 42
        hoverEnabled: true
        Accessible.name: playlist.title
        background: Rectangle {
            radius: 7
            color: row.selected ? Theme.accentSurface : row.hovered ? Theme.hover : "transparent"
            border.color: row.activeFocus ? Theme.accent : "transparent"
        }
        contentItem: RowLayout {
            spacing: 8
            Item { Layout.preferredWidth: 4 }
            Cover {
                Layout.preferredWidth: 28
                Layout.preferredHeight: 28
                source: row.playlist.art
            }
            Label {
                Layout.fillWidth: true
                text: row.playlist.title
                color: row.selected ? Theme.text : Theme.secondary
                font.pixelSize: 12
                elide: Text.ElideRight
            }
            Item { Layout.preferredWidth: 3 }
        }
    }

    component Divider: Rectangle {
        Layout.fillWidth: true
        Layout.leftMargin: 5
        Layout.rightMargin: 5
        Layout.topMargin: 8
        Layout.bottomMargin: 8
        Layout.preferredHeight: 1
        color: Theme.line
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 12
        spacing: 0

        RowLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: 74
            Layout.leftMargin: 4
            spacing: 10
            Image {
                Layout.preferredWidth: 36
                Layout.preferredHeight: 36
                source: "qrc:/branding/assets/netease-music.png"
                fillMode: Image.PreserveAspectFit
            }
            Label {
                Layout.fillWidth: true
                text: "网易云音乐"
                color: Theme.text
                font.pixelSize: 20
                font.weight: Font.Bold
                elide: Text.ElideRight
            }
        }

        ScrollView {
            id: scroll
            Layout.fillWidth: true
            Layout.fillHeight: true
            contentWidth: availableWidth
            clip: true
            ScrollBar.horizontal.policy: ScrollBar.AlwaysOff

            ColumnLayout {
                width: scroll.availableWidth
                spacing: 2
                Repeater {
                    model: [
                        {key:"recommend", title:"推荐", glyph:"home"},
                        {key:"essential", title:"精选", glyph:"collection"},
                        {key:"podcasts", title:"播客", glyph:"podcast"},
                        {key:"roam", title:"漫游", glyph:"disc"},
                        {key:"following", title:"关注", glyph:"people"}
                    ]
                    delegate: NavRow {
                        required property var modelData
                        Layout.fillWidth: true
                        text: modelData.title
                        glyph: modelData.glyph
                        selected: rail.activeSection === modelData.key
                        onClicked: rail.navigate(modelData.key)
                    }
                }

                Divider {}

                Repeater {
                    model: [
                        {key:"liked", title:"我喜欢的音乐", glyph:"heart"},
                        {key:"recent", title:"最近播放", glyph:"history"},
                        {key:"myPodcasts", title:"我的播客", glyph:"podcast"},
                        {key:"collections", title:"我的收藏", glyph:"star"}
                    ]
                    delegate: NavRow {
                        required property var modelData
                        Layout.fillWidth: true
                        text: modelData.title
                        glyph: modelData.glyph
                        selected: rail.activeSection === modelData.key
                        onClicked: rail.navigate(modelData.key)
                    }
                }

                Divider {}

                RowLayout {
                    Layout.fillWidth: true
                    NavRow {
                        Layout.fillWidth: true
                        text: "创建的歌单" + (rail.library.loggedIn ? "  " + rail.library.createdPlaylists.length : "")
                        glyph: rail.showCreated ? "down" : "chevron"
                        onClicked: rail.showCreated = !rail.showCreated
                    }
                    IconButton {
                        symbol: "plus"
                        text: "创建歌单"
                        Layout.preferredWidth: 29
                        Layout.preferredHeight: 29
                        onClicked: rail.library.loggedIn ? rail.createRequested() : rail.loginRequested()
                    }
                }

                Repeater {
                    model: rail.showCreated ? rail.library.createdPlaylists : []
                    delegate: PlaylistRow {
                        required property var modelData
                        Layout.fillWidth: true
                        playlist: modelData
                        selected: rail.selectedPlaylist === modelData.id
                        onClicked: rail.playlistChosen(modelData)
                    }
                }
                NavRow {
                    Layout.fillWidth: true
                    visible: rail.showCreated && !rail.library.loggedIn
                    glyph: "user"
                    text: "登录后同步歌单"
                    onClicked: rail.loginRequested()
                }
                Label {
                    Layout.leftMargin: 12
                    Layout.topMargin: 6
                    Layout.bottomMargin: 5
                    visible: rail.showCreated && rail.library.loggedIn && rail.library.createdPlaylists.length === 0
                    text: "暂无创建的歌单"
                    color: Theme.muted
                    font.pixelSize: 11
                }

                Divider { visible: rail.library.savedPlaylists.length > 0 }
                NavRow {
                    Layout.fillWidth: true
                    visible: rail.library.savedPlaylists.length > 0
                    text: "收藏的歌单  " + rail.library.savedPlaylists.length
                    glyph: rail.showSaved ? "down" : "chevron"
                    onClicked: rail.showSaved = !rail.showSaved
                }
                Repeater {
                    model: rail.showSaved ? rail.library.savedPlaylists : []
                    delegate: PlaylistRow {
                        required property var modelData
                        Layout.fillWidth: true
                        playlist: modelData
                        selected: rail.selectedPlaylist === modelData.id
                        onClicked: rail.playlistChosen(modelData)
                    }
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.leftMargin: 7
            Layout.preferredHeight: 34
            spacing: 7
            Rectangle {
                Layout.preferredWidth: 5
                Layout.preferredHeight: 5
                radius: 3
                color: rail.library.backendReady ? Theme.success : Theme.muted
            }
            Label {
                text: rail.library.backendStatus
                color: Theme.muted
                font.pixelSize: 11
            }
        }
    }
}
