pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtMultimedia

ApplicationWindow {
    id: window
    required property Library library
    width: 1340
    height: 880
    minimumWidth: 820
    minimumHeight: 620
    visible: true
    flags: Qt.Window | Qt.FramelessWindowHint
    title: "网易云音乐"
    color: Theme.window
    font.family: Theme.font
    palette.window: Theme.window
    palette.base: Theme.panel
    palette.text: Theme.text
    palette.windowText: Theme.text
    palette.placeholderText: Theme.muted
    palette.buttonText: Theme.text
    palette.highlight: Theme.accent
    palette.highlightedText: Theme.ink

    readonly property int discovery: 0
    readonly property int search: 1
    readonly property int queue: 2
    readonly property int playlist: 3
    readonly property int browsePage: 4
    readonly property int nowPlaying: 5
    property int page: discovery
    property bool nowPlayingVisible: false
    readonly property int sidebarPage: page === playlist ? playlistReturnPage : page
    property string toastText
    property int queueReturnPage: discovery
    property int playlistReturnPage: discovery
    readonly property string playingId: library.currentTrack.id || ""
    readonly property bool playing: library.media.playbackState === MediaPlayer.PlayingState

    function toggleMaximized() {
        if (window.visibility === Window.Maximized)
            window.showNormal()
        else
            window.showMaximized()
    }

    component TitleDragArea: Item {
        TapHandler {
            acceptedButtons: Qt.LeftButton
            onDoubleTapped: window.toggleMaximized()
        }
        DragHandler {
            target: null
            acceptedButtons: Qt.LeftButton
            onActiveChanged: {
                if (active)
                    window.startSystemMove()
            }
        }
    }

    function searchFor(term: string) {
        if (!term.trim().length)
            return
        window.nowPlayingVisible = false
        window.page = window.search
        window.library.search(term)
    }

    function showQueue() {
        window.nowPlayingVisible = false
        if (window.page === window.queue) {
            window.page = window.queueReturnPage
            return
        }
        window.queueReturnPage = window.page
        window.page = window.queue
    }

    Shortcut {
        sequence: "Ctrl+K"
        onActivated: {
            searchInput.forceActiveFocus()
            searchInput.selectAll()
        }
    }
    Shortcut {
        sequence: "Escape"
        enabled: window.nowPlayingVisible
        onActivated: window.nowPlayingVisible = false
    }

    function sidebarKey(key: string): string {
        if (["essential", "officialPlaylists", "essentialPodcasts", "featured", "charts",
            "artists", "newTracks", "albums", "vip", "vipCharts", "vipSongs"].includes(key))
            return "essential"
        if (key.startsWith("podcast"))
            return "podcasts"
        if (key.startsWith("recent"))
            return "recent"
        if (["myPodcasts", "createdVoices", "myRecentVoices", "savedVoices", "boughtVoices", "likedVoices"].includes(key))
            return "myPodcasts"
        if (["collections", "savedAlbums", "savedArtists", "savedVideos"].includes(key))
            return "collections"
        if (key.startsWith("following"))
            return "following"
        return key === "daily" || key.startsWith("scene") ? "recommend" : key
    }

    function showBrowse(key: string) {
        window.nowPlayingVisible = false
        window.page = window.browsePage
        window.library.browse(key)
    }

    function showPlaylist(data: var, playNow: bool) {
        window.nowPlayingVisible = false
        if (window.page !== window.playlist)
            window.playlistReturnPage = window.page
        window.page = window.playlist
        window.library.openPlaylist(data, playNow)
    }

    Dialog {
        id: postDialog
        anchors.centerIn: Overlay.overlay
        width: 420
        modal: true
        standardButtons: Dialog.Close
        contentItem: ScrollView {
            implicitHeight: Math.min(postText.implicitHeight + 16, 320)
            ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
            Label {
                id: postText
                width: 380
                wrapMode: Text.Wrap
                color: Theme.text
                textFormat: Text.PlainText
            }
        }
        background: Rectangle {
            color: Theme.panel
            radius: 10
            border.color: Theme.line
        }
    }

    LoginDialog {
        id: login
        library: window.library
    }

    Dialog {
        id: makePlaylist
        title: "创建歌单"
        anchors.centerIn: Overlay.overlay
        modal: true
        width: 335
        palette.window: Theme.panel
        palette.base: Theme.raised
        palette.text: Theme.text
        palette.buttonText: Theme.text
        onOpened: {
            playlistName.text = ""
            playlistName.forceActiveFocus()
        }
        onAccepted: window.library.createPlaylist(playlistName.text)
        contentItem: TextField {
            id: playlistName
            placeholderText: "输入歌单名称"
            maximumLength: 40
            onAccepted: {
                if (text.trim().length)
                    makePlaylist.accept()
            }
        }
        footer: DialogButtonBox {
            Button {
                text: "取消"
                DialogButtonBox.buttonRole: DialogButtonBox.RejectRole
            }
            Button {
                text: "创建"
                enabled: playlistName.text.trim().length > 0
                DialogButtonBox.buttonRole: DialogButtonBox.AcceptRole
            }
        }
    }

    Timer {
        id: toastTimer
        interval: 4000
        onTriggered: window.toastText = ""
    }

    Connections {
        target: window.library
        function onNotification(message) {
            window.toastText = message
            toastTimer.restart()
        }
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 0
        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 0

            Sidebar {
                id: navigationSidebar
                Layout.fillHeight: true
                Layout.preferredWidth: window.width >= 1050 ? 225 : 188
                library: window.library
                activeSection: window.sidebarPage === window.discovery ? "recommend"
                               : window.sidebarPage !== window.browsePage ? ""
                               : window.sidebarKey(window.library.section)
                selectedPlaylist: window.page === window.playlist ? window.library.playlist.id || "" : ""
                onLoginRequested: login.open()
                onCreateRequested: makePlaylist.open()
                onPlaylistChosen: (data) => window.showPlaylist(data, false)
                onNavigate: (key) => {
                    if (key === "recommend") {
                        window.nowPlayingVisible = false
                        window.page = window.discovery
                    } else {
                        window.showBrowse(key)
                    }
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 0
                RowLayout {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 72
                    Layout.leftMargin: 32
                    Layout.rightMargin: 13
                    spacing: 8
                    TextField {
                        id: searchInput
                        objectName: "searchInput"
                        Layout.preferredWidth: 365
                        Layout.minimumWidth: 142
                        Layout.maximumWidth: 425
                        Layout.fillWidth: true
                        Layout.preferredHeight: 39
                        leftPadding: 35
                        rightPadding: 65
                        placeholderText: "搜索歌曲或艺人"
                        selectByMouse: true
                        font.pixelSize: 13
                        color: Theme.text
                        placeholderTextColor: Theme.muted
                        Accessible.name: "搜索歌曲或艺人"
                        onAccepted: window.searchFor(text)
                        background: Rectangle {
                            radius: 10
                            color: Theme.panel
                            border.color: searchInput.activeFocus ? Theme.accent : Theme.line
                        }
                        Symbol {
                            anchors.left: parent.left
                            anchors.leftMargin: 11
                            anchors.verticalCenter: parent.verticalCenter
                            width: 16
                            height: 16
                            name: "search"
                        }
                        Label {
                            anchors.right: parent.right
                            anchors.rightMargin: 12
                            anchors.verticalCenter: parent.verticalCenter
                            text: "Ctrl K"
                            color: Theme.muted
                            font.pixelSize: 11
                        }
                    }
                    Button {
                        id: searchButton
                        text: "搜索"
                        objectName: "submitSearch"
                        enabled: searchInput.text.trim().length > 0
                        onClicked: window.searchFor(searchInput.text)
                        Layout.preferredHeight: 39
                        background: Rectangle {
                            implicitWidth: 60
                            radius: 10
                            color: searchButton.hovered ? Theme.hover : Theme.raised
                            border.color: searchButton.activeFocus ? Theme.accent : Theme.line
                            opacity: searchButton.enabled ? 1 : .55
                        }
                    }
                    TitleDragArea {
                        Layout.fillHeight: true
                        Layout.fillWidth: true
                        Layout.minimumWidth: 24
                    }
                    Button {
                        id: accountButton
                        Layout.preferredHeight: 39
                        Layout.maximumWidth: 156
                        enabled: window.library.backendReady && window.library.localAccountSupported
                        text: window.library.loggedIn ? window.library.profile.nickname : "扫码登录"
                        Accessible.name: text
                        onClicked: login.open()
                        background: Rectangle {
                            implicitWidth: 110
                            radius: 9
                            color: accountButton.hovered ? Theme.hover : Theme.accentSurface
                            border.color: accountButton.activeFocus ? Theme.accent : Theme.line
                            opacity: accountButton.enabled ? 1 : .45
                        }
                        contentItem: RowLayout {
                            spacing: 7
                            Cover {
                                Layout.preferredWidth: 21
                                Layout.preferredHeight: 21
                                visible: window.library.loggedIn
                                source: window.library.profile.avatarUrl || ""
                            }
                            Symbol {
                                Layout.preferredWidth: 15
                                Layout.preferredHeight: 15
                                name: "user"
                                tint: Theme.accent
                                visible: !window.library.loggedIn
                            }
                            Label {
                                Layout.fillWidth: true
                                text: accountButton.text
                                color: Theme.text
                                elide: Text.ElideRight
                                horizontalAlignment: Text.AlignHCenter
                                font.pixelSize: 12
                            }
                        }
                    }
                    RowLayout {
                        Layout.leftMargin: 4
                        spacing: 2
                        IconButton {
                            Layout.preferredWidth: 29
                            Layout.preferredHeight: 30
                            symbol: "minimize"
                            text: "最小化"
                            onClicked: window.showMinimized()
                        }
                        IconButton {
                            Layout.preferredWidth: 29
                            Layout.preferredHeight: 30
                            symbol: window.visibility === Window.Maximized ? "restore" : "maximize"
                            text: window.visibility === Window.Maximized ? "恢复窗口" : "最大化"
                            onClicked: window.toggleMaximized()
                        }
                        IconButton {
                            Layout.preferredWidth: 29
                            Layout.preferredHeight: 30
                            symbol: "close"
                            text: "关闭窗口"
                            onClicked: window.close()
                        }
                    }
                }

                StackLayout {
                    id: pages
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    currentIndex: window.nowPlayingVisible ? window.nowPlaying : window.page
                    Layout.leftMargin: currentIndex === window.discovery ? 0 : 32
                    Layout.rightMargin: currentIndex === window.discovery ? 0 : 32

                    DiscoverPage {
                        library: window.library
                        onChoosePlaylist: (playlistData, playNow) => window.showPlaylist(playlistData, playNow)
                        onNavigate: (key) => window.showBrowse(key)
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        spacing: 12

                        Label {
                            Layout.fillWidth: true
                            text: "搜索"
                            color: Theme.text
                            font.pixelSize: 31
                            font.weight: Font.Bold
                        }
                        Label {
                            Layout.fillWidth: true
                            visible: window.library.searchTerm.length > 0
                            text: "“" + window.library.searchTerm + "”" +
                                  (window.library.searchBusy ? "" : " · " + window.library.searchResults.length + " 首歌曲")
                            color: Theme.secondary
                            font.pixelSize: 13
                            elide: Text.ElideRight
                        }
                        StatusView {
                            Layout.fillWidth: true
                            Layout.topMargin: 38
                            symbol: "search"
                            visible: window.library.searchBusy || window.library.searchResults.length === 0
                            busy: window.library.searchBusy
                            title: busy ? "正在搜索…" : window.library.searchError.length ? "搜索暂不可用"
                                  : window.library.searchTerm.length ? "没有找到对应歌曲" : "搜索歌曲或艺人"
                            detail: window.library.searchError.length ? window.library.searchError
                                   : window.library.searchTerm.length && !busy ? "可以换一个关键词再试试。" : ""
                            actionText: window.library.searchError.length ? "重试" : ""
                            onAction: window.library.search(window.library.searchTerm)
                        }
                        TrackList {
                            objectName: "searchResults"
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            tracks: window.library.searchResults
                            visible: tracks.length > 0
                            currentId: window.playingId
                            playing: window.playing
                            onActivated: (index) => window.library.playCollection(tracks, index)
                        }
                        Item { Layout.fillHeight: true; visible: window.library.searchResults.length === 0 }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        spacing: 12
                        RowLayout {
                            Layout.fillWidth: true
                            Label {
                                Layout.fillWidth: true
                                text: "播放队列"
                                color: Theme.text
                                font.pixelSize: 31
                                font.weight: Font.Bold
                            }
                            Label {
                                text: window.library.queue.length + " 首歌曲"
                                color: Theme.secondary
                                font.pixelSize: 13
                            }
                        }
                        StatusView {
                            Layout.fillWidth: true
                            Layout.topMargin: 42
                            visible: window.library.queue.length === 0
                            symbol: "queue"
                            title: "队列还没有歌曲"
                            detail: "从发现页、歌单或搜索结果中选择歌曲。"
                        }
                        TrackList {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            tracks: window.library.queue
                            visible: tracks.length > 0
                            currentId: window.playingId
                            playing: window.playing
                            onActivated: (index) => window.library.playIndex(index)
                        }
                        Item { Layout.fillHeight: true; visible: window.library.queue.length === 0 }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        spacing: 13
                        RowLayout {
                            Layout.fillWidth: true
                            IconButton {
                                symbol: "back"
                                text: "返回"
                                onClicked: window.page = window.playlistReturnPage
                            }
                            Label {
                                Layout.fillWidth: true
                                text: window.library.playlist.kind === "radio" ? "播客"
                                    : (window.library.playlist.kind === "chart" || window.library.playlist.kind === "vipChart") ? "排行榜"
                                    : window.library.playlist.kind === "album" ? "专辑"
                                    : window.library.playlist.kind === "program" ? "节目和关联歌曲"
                                    : window.library.playlist.kind === "artist" ? "歌手歌曲"
                                    : window.library.playlist.kind === "voiceList" ? "播客列表" : "歌单"
                                color: Theme.secondary
                                font.pixelSize: 13
                            }
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 17
                            Cover {
                                Layout.preferredWidth: 94
                                Layout.preferredHeight: 94
                                source: window.library.playlist.art || ""
                            }
                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 5
                                Label {
                                    Layout.fillWidth: true
                                    text: window.library.playlist.title || ""
                                    color: Theme.text
                                    font.pixelSize: 25
                                    font.weight: Font.Bold
                                    elide: Text.ElideRight
                                }
                                Label {
                                    Layout.fillWidth: true
                                    text: (window.library.playlist.description || "") +
                                          (window.library.playlist.description ? " · " : "") +
                                          (window.library.playlistHasMore ? "已加载 " : "") +
                                          window.library.playlistTracks.length +
                                          (window.library.playlist.trackCount > window.library.playlistTracks.length
                                           && window.library.playlistHasMore ? " / " + window.library.playlist.trackCount : "") +
                                          (window.library.playlist.kind === "radio" || window.library.playlist.kind === "voiceList"
                                           ? " 期节目" : " 个音频")
                                    color: Theme.secondary
                                    font.pixelSize: 13
                                }
                                Button {
                                    id: playPlaylistButton
                                    Layout.topMargin: 5
                                    text: "播放全部"
                                    enabled: window.library.playlistTracks.length > 0
                                    onClicked: window.library.playAll(window.library.playlistTracks)
                                    palette.buttonText: Theme.ink
                                    background: Rectangle {
                                        implicitHeight: 34
                                        implicitWidth: 85
                                        radius: 9
                                        color: Theme.accent
                                        opacity: playPlaylistButton.enabled ? 1 : .42
                                    }
                                }
                            }
                        }
                        StatusView {
                            Layout.fillWidth: true
                            Layout.topMargin: 20
                            busy: window.library.playlistBusy
                            visible: window.library.playlistTracks.length === 0
                            title: busy ? "正在加载曲目…" : window.library.playlistError.length ? "曲目暂不可用" : "暂无曲目"
                            detail: window.library.playlistError
                            actionText: window.library.playlistError.length ? "重试" : ""
                            onAction: window.library.openPlaylist(window.library.playlist, false)
                        }
                        TrackList {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            tracks: window.library.playlistTracks
                            visible: tracks.length > 0
                            currentId: window.playingId
                            playing: window.playing
                            onActivated: (index) => window.library.playCollection(tracks, index)
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            visible: window.library.playlistHasMore && window.library.playlistTracks.length > 0
                            spacing: 10
                            Label {
                                Layout.fillWidth: true
                                text: window.library.playlistError
                                color: Theme.danger
                                elide: Text.ElideRight
                            }
                            Button {
                                text: window.library.playlistBusy ? "加载中…" : "加载更多"
                                enabled: !window.library.playlistBusy
                                onClicked: window.library.loadMorePlaylist()
                            }
                        }
                        Item { Layout.fillHeight: true; visible: window.library.playlistTracks.length === 0 }
                    }

                    BrowsePage {
                        library: window.library
                        onLoginRequested: login.open()
                        onPlaylistChosen: (data) => window.showPlaylist(data, false)
                        onPostChosen: (author, message) => {
                            postDialog.title = author
                            postText.text = message
                            postDialog.open()
                        }
                    }
                    NowPlayingPage {
                        library: window.library
                        onCloseRequested: window.nowPlayingVisible = false
                    }
                }
            }
        }
        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 34
            visible: window.toastText.length > 0 || window.library.playbackError.length > 0
            color: "#382532"
            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 22
                anchors.rightMargin: 22
                Label {
                    Layout.fillWidth: true
                    text: window.toastText || window.library.playbackError
                    color: window.toastText.length ? Theme.text : Theme.danger
                    font.pixelSize: 12
                    elide: Text.ElideRight
                }
                Button {
                    id: switchStream
                    Layout.preferredHeight: 26
                    text: "切换音源"
                    visible: window.toastText.length === 0 && window.library.playbackError.length > 0
                        && window.library.queueIndex >= 0 && !window.library.playbackBusy
                    onClicked: window.library.switchAudioStream()
                    background: Rectangle {
                        radius: 6
                        color: switchStream.hovered ? Theme.hover : Theme.panel
                        border.color: switchStream.activeFocus ? Theme.accent : Theme.line
                    }
                }
            }
        }
        PlayerBar {
            Layout.fillWidth: true
            library: window.library
            queueVisible: !window.nowPlayingVisible && window.page === window.queue
            nowPlayingVisible: window.nowPlayingVisible
            onQueueRequested: window.showQueue()
            onNowPlayingRequested: window.nowPlayingVisible = !window.nowPlayingVisible
            onLoginRequested: login.open()
        }
    }
    TitleDragArea {
        anchors.left: parent.left
        anchors.top: parent.top
        width: navigationSidebar.width
        height: 70
    }

    WindowResize {
        anchors.fill: parent
        hostWindow: window
    }

}
