import QtQuick

Canvas {
    id: symbol
    property string name: "disc"
    property color tint: Theme.secondary
    implicitWidth: 20
    implicitHeight: 20
    onNameChanged: requestPaint()
    onTintChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()

    onPaint: {
        const c = getContext("2d")
        c.reset()
        c.clearRect(0, 0, width, height)
        c.scale(width / 24, height / 24)
        c.strokeStyle = tint
        c.fillStyle = tint
        c.lineWidth = 1.65
        c.lineJoin = "round"
        c.lineCap = "round"

        function line(x1, y1, x2, y2) {
            c.beginPath()
            c.moveTo(x1, y1)
            c.lineTo(x2, y2)
            c.stroke()
        }
        function circle(x, y, r) {
            c.beginPath()
            c.arc(x, y, r, 0, 2 * Math.PI)
            c.stroke()
        }
        function triangle(x, y, w, h) {
            c.beginPath()
            c.moveTo(x, y - h / 2)
            c.lineTo(x + w, y)
            c.lineTo(x, y + h / 2)
            c.closePath()
            c.fill()
        }

        switch (name) {
        case "search":
            circle(10.3, 10.3, 5.7)
            line(14.5, 14.5, 20, 20)
            break
        case "disc":
            circle(12, 12, 9)
            circle(12, 12, 2.3)
            c.beginPath()
            c.arc(12, 12, 6, 3.5, 4.7)
            c.stroke()
            c.beginPath()
            c.arc(12, 12, 6, 0.35, 1.6)
            c.stroke()
            break
        case "queue":
            line(4, 6, 20, 6)
            line(4, 12, 15, 12)
            line(4, 18, 12, 18)
            triangle(16, 16.5, 5, 6)
            break
        case "play":
            triangle(8, 12, 10, 13)
            break
        case "pause":
            c.fillRect(7, 5, 3.5, 14)
            c.fillRect(13.5, 5, 3.5, 14)
            break
        case "next":
            triangle(6, 12, 10, 11)
            c.fillRect(17, 6.5, 2, 11)
            break
        case "previous":
            c.translate(24, 0)
            c.scale(-1, 1)
            triangle(6, 12, 10, 11)
            c.fillRect(17, 6.5, 2, 11)
            break
        case "volume":
        case "muted":
            c.beginPath()
            c.moveTo(3, 9)
            c.lineTo(7, 9)
            c.lineTo(12, 5)
            c.lineTo(12, 19)
            c.lineTo(7, 15)
            c.lineTo(3, 15)
            c.closePath()
            c.stroke()
            if (name === "muted") {
                line(16, 9, 21, 15)
                line(21, 9, 16, 15)
            } else {
                c.beginPath()
                c.arc(12, 12, 5, -0.75, 0.75)
                c.stroke()
                c.beginPath()
                c.arc(12, 12, 8.5, -0.75, 0.75)
                c.stroke()
            }
            break
        case "home":
            c.beginPath()
            c.moveTo(3, 11)
            c.lineTo(12, 4)
            c.lineTo(21, 11)
            c.lineTo(19, 11)
            c.lineTo(19, 20)
            c.lineTo(5, 20)
            c.lineTo(5, 11)
            c.closePath()
            c.stroke()
            line(12, 15, 12, 20)
            break
        case "collection":
            c.strokeRect(5, 8, 14, 12)
            line(7, 4, 17, 4)
            line(12, 11, 12, 17)
            line(12, 11, 16, 10)
            break
        case "podcast":
            circle(12, 11, 2.3)
            line(12, 13.5, 12, 20)
            for (const radius of [5, 8.5]) {
                c.beginPath()
                c.arc(12, 11, radius, Math.PI * .72, Math.PI * 1.28)
                c.stroke()
                c.beginPath()
                c.arc(12, 11, radius, -.88, .88)
                c.stroke()
            }
            break
        case "people":
        case "user":
            circle(name === "people" ? 9 : 12, 8, 3)
            c.beginPath()
            c.arc(name === "people" ? 9 : 12, 20, 5.5, Math.PI, 2 * Math.PI)
            c.stroke()
            if (name === "people") {
                c.beginPath()
                c.arc(16, 8, 2.4, -1.1, 1.1)
                c.stroke()
                c.beginPath()
                c.arc(16.5, 20, 4.2, 4.7, 6.2)
                c.stroke()
            }
            break
        case "heart":
            c.beginPath()
            c.moveTo(12, 20)
            c.bezierCurveTo(8, 17, 3, 13, 3, 9)
            c.bezierCurveTo(3, 4, 9, 3, 12, 7)
            c.bezierCurveTo(15, 3, 21, 4, 21, 9)
            c.bezierCurveTo(21, 13, 16, 17, 12, 20)
            c.closePath()
            c.stroke()
            break
        case "history":
            circle(12, 12, 8.5)
            line(12, 7, 12, 12)
            line(12, 12, 16, 14)
            break
        case "star":
            c.beginPath()
            for (let index = 0; index < 10; ++index) {
                const angle = -Math.PI / 2 + index * Math.PI / 5
                const radius = index % 2 === 0 ? 9 : 4.2
                const x = 12 + Math.cos(angle) * radius
                const y = 12 + Math.sin(angle) * radius
                if (index === 0) c.moveTo(x, y)
                else c.lineTo(x, y)
            }
            c.closePath()
            c.stroke()
            break
        case "up":
            line(6, 15, 12, 9)
            line(12, 9, 18, 15)
            break
        case "down":
            line(6, 9, 12, 15)
            line(12, 15, 18, 9)
            break
        case "plus":
            line(5, 12, 19, 12)
            line(12, 5, 12, 19)
            break
        case "output":
            c.strokeRect(5, 5, 14, 11)
            line(9, 20, 15, 20)
            line(12, 16, 12, 20)
            break
        case "trash":
            line(5, 7, 19, 7)
            line(9, 4, 15, 4)
            line(7, 7, 8, 20)
            line(17, 7, 16, 20)
            line(8, 20, 16, 20)
            line(11, 10, 11, 17)
            line(14, 10, 14, 17)
            break
        case "refresh":
            c.beginPath()
            c.arc(12, 12, 7, -0.65, 4.9)
            c.stroke()
            line(18, 5, 18, 10)
            line(18, 10, 13, 10)
            break
        case "chevron":
            line(9, 5, 16, 12)
            line(16, 12, 9, 19)
            break
        case "back":
            line(10, 6, 4, 12)
            line(4, 12, 10, 18)
            line(4, 12, 20, 12)
            break
        case "minimize":
            line(6, 13, 18, 13)
            break
        case "maximize":
            c.strokeRect(6, 6, 12, 12)
            break
        case "restore":
            c.strokeRect(5, 9, 10, 10)
            line(9, 9, 9, 5)
            line(9, 5, 19, 5)
            line(19, 5, 19, 15)
            line(19, 15, 15, 15)
            break
        case "close":
            line(6, 6, 18, 18)
            line(6, 18, 18, 6)
            break
        case "music":
            line(10, 6, 10, 17)
            line(10, 6, 19, 4)
            line(19, 4, 19, 15)
            circle(7, 17, 3)
            circle(16, 15, 3)
            break
        }
    }
}
