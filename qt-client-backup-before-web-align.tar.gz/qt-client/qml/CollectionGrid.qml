pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

GridLayout {
    id: grid
    required property var entries
    property bool singleRow: true
    property int minimumColumnWidth: 146
    property int maximumCoverHeight: 153
    property bool showPlays: false
    signal chosen(var entry)
    columns: Math.max(2, Math.min(6, Math.floor((width + columnSpacing) / minimumColumnWidth)))
    columnSpacing: 12
    rowSpacing: 12

    Repeater {
        model: grid.singleRow ? grid.entries.slice(0, grid.columns) : grid.entries
        delegate: AbstractButton {
            id: card
            required property var modelData
            readonly property bool daily: modelData.kind === "daily"
            Layout.fillWidth: true
            Layout.preferredWidth: 1
            Layout.preferredHeight: Math.min(grid.maximumCoverHeight, Math.max(0, width - 18)) + 78
            padding: 9
            hoverEnabled: true
            focusPolicy: Qt.StrongFocus
            Accessible.name: modelData.title
            onClicked: grid.chosen(modelData)
            background: Rectangle {
                radius: 11
                color: card.hovered || card.activeFocus ? Theme.raised : Theme.panel
                border.color: card.activeFocus ? Theme.accent : Theme.line
            }
            contentItem: ColumnLayout {
                spacing: 5
                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: Math.min(grid.maximumCoverHeight, width)
                    Cover {
                        anchors.fill: parent
                        visible: !card.daily
                        source: card.daily ? "" : card.modelData.art
                    }
                    Label {
                        anchors.right: parent.right
                        anchors.top: parent.top
                        anchors.margins: 6
                        visible: grid.showPlays && Number(card.modelData.playCount) > 0
                        text: Number(card.modelData.playCount) >= 10000
                            ? (Number(card.modelData.playCount) / 10000).toFixed(1) + "万播放"
                            : Number(card.modelData.playCount) + "次播放"
                        padding: 5
                        font.pixelSize: 11
                        color: "white"
                        background: Rectangle { radius: 6; color: "#bb17131a" }
                    }
                    Rectangle {
                        anchors.fill: parent
                        visible: card.daily
                        radius: 7
                        gradient: Gradient {
                            GradientStop { position: 0; color: "#a54966" }
                            GradientStop { position: 1; color: "#482936" }
                        }
                        Rectangle {
                            anchors.centerIn: parent
                            width: Math.min(66, parent.width * .55)
                            height: width
                            radius: 12
                            color: "#3c222e"
                            border.color: "#eb9ea7"
                            Label {
                                anchors.centerIn: parent
                                text: Qt.formatDate(new Date(), "dd")
                                color: "#fff2ee"
                                font.pixelSize: 31
                                font.weight: Font.Bold
                            }
                        }
                    }
                }
                Label {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 35
                    text: card.modelData.title
                    color: Theme.text
                    font.pixelSize: 12
                    font.weight: Font.DemiBold
                    wrapMode: Text.Wrap
                    maximumLineCount: 2
                    elide: Text.ElideRight
                }
                Label {
                    Layout.fillWidth: true
                    text: card.daily || card.modelData.kind === "album"
                          ? card.modelData.description || ""
                          : card.modelData.trackCount ? card.modelData.trackCount + " 首歌曲" : ""
                    color: Theme.muted
                    elide: Text.ElideRight
                    font.pixelSize: 11
                }
            }
        }
    }
}
