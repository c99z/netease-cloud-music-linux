import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ColumnLayout {
    id: root
    property string title
    property string detail
    property string actionText
    property bool busy: false
    property string symbol: "disc"
    signal action()
    spacing: 11

    Item { Layout.preferredHeight: 12 }
    Rectangle {
        Layout.alignment: Qt.AlignHCenter
        Layout.preferredWidth: 52
        Layout.preferredHeight: 52
        radius: 16
        color: Theme.accentSurface

        BusyIndicator {
            anchors.centerIn: parent
            width: 32
            height: 32
            running: root.busy
            visible: running
        }
        Symbol {
            anchors.centerIn: parent
            name: root.symbol
            tint: Theme.accent
            width: 24
            height: 24
            visible: !root.busy
        }
    }
    Label {
        Layout.alignment: Qt.AlignHCenter
        text: root.title
        color: Theme.text
        font.pixelSize: 17
        font.bold: true
    }
    Label {
        Layout.fillWidth: true
        Layout.maximumWidth: 420
        Layout.alignment: Qt.AlignHCenter
        horizontalAlignment: Text.AlignHCenter
        visible: text.length > 0
        text: root.detail
        color: Theme.secondary
        wrapMode: Text.WordWrap
        font.pixelSize: 13
    }
    Button {
        id: actionButton
        Layout.alignment: Qt.AlignHCenter
        visible: root.actionText.length > 0
        text: root.actionText
        onClicked: root.action()
        palette.buttonText: Theme.text
        background: Rectangle {
            implicitWidth: 82
            implicitHeight: 34
            radius: 9
            color: actionButton.hovered ? Theme.hover : Theme.raised
            border.color: Theme.line
        }
    }
    Item { Layout.preferredHeight: 12 }
}
