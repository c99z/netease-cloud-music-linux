import QtQuick

Item {
    id: art
    property url coverSource
    clip: true

    Canvas {
        anchors.fill: parent
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        onPaint: {
            const c = getContext("2d")
            c.reset()
            c.clearRect(0, 0, width, height)
            const r = Math.min(height * .54, width * .34)
            const x = width * .64
            const y = height * .51

            for (let k = 0; k < 9; ++k) {
                c.beginPath()
                c.arc(x, y, r + 16 + k * 12, 0, Math.PI * 2)
                c.strokeStyle = "rgba(211,191,255,0.13)"
                c.lineWidth = 1
                c.stroke()
            }

            c.save()
            c.translate(x, y)
            const record = c.createLinearGradient(-r, -r, r * .8, r)
            record.addColorStop(0, "#3b3038")
            record.addColorStop(.28, "#150f17")
            record.addColorStop(.57, "#291b25")
            record.addColorStop(.77, "#55404a")
            record.addColorStop(1, "#1a1219")
            c.beginPath()
            c.arc(0, 0, r, 0, 2 * Math.PI)
            c.fillStyle = record
            c.fill()
            c.lineWidth = 1
            c.strokeStyle = "#866174"
            c.stroke()
            for (let radius = r - 4; radius > r * .31; radius -= 3.7) {
                c.beginPath()
                c.arc(0, 0, radius, 0, 2 * Math.PI)
                c.strokeStyle = radius % 3 > 1.7 ? "rgba(236,220,255,.18)" : "rgba(9,5,16,.48)"
                c.stroke()
            }
            c.beginPath()
            c.arc(0, 0, r * .29, 0, 2 * Math.PI)
            const label = c.createLinearGradient(-r / 4, -r / 4, r / 4, r / 4)
            label.addColorStop(0, "#ffe0d9")
            label.addColorStop(1, "#e48095")
            c.fillStyle = label
            c.fill()
            c.beginPath()
            c.arc(0, 0, 5, 0, 2 * Math.PI)
            c.fillStyle = "#421d32"
            c.fill()
            c.restore()
        }
    }

    Rectangle {
        width: Math.min(art.height * .62, art.width * .33)
        height: width
        x: art.width * .24 - width / 2 + 4
        y: (art.height - height) / 2 + 7
        rotation: -11
        radius: 6
        color: "#321725"
        opacity: 0.68
        visible: sleeve.visible
    }
    Rectangle {
        id: sleeve
        width: Math.min(art.height * .62, art.width * .33)
        height: width
        x: art.width * .24 - width / 2
        y: (art.height - height) / 2
        rotation: -11
        radius: 6
        color: "#f2c3c7"
        visible: art.coverSource.toString().length > 0
        Cover {
            anchors.fill: parent
            anchors.margins: 4
            source: art.coverSource
            edge: 4
        }
    }
}
