pragma Singleton
import QtQuick

QtObject {
    readonly property color window: "#141317"
    readonly property color rail: "#1c191f"
    readonly property color panel: "#221f26"
    readonly property color raised: "#2b252d"
    readonly property color hover: "#372d36"
    readonly property color line: "#3a3039"
    readonly property color bufferedAudio: "#986e81"
    readonly property color text: "#f8f0f1"
    readonly property color secondary: "#c6b5bf"
    readonly property color muted: "#ad99a4"
    readonly property color accent: "#ff7e88"
    readonly property color ink: "#2b1016"
    readonly property color accentSurface: "#43252e"
    readonly property color danger: "#ffc0b0"
    readonly property color success: "#99d6b5"
    readonly property string font: "Noto Sans CJK SC"

    function time(ms: real): string {
        let seconds = Math.max(0, Math.floor(ms / 1000))
        return Math.floor(seconds / 60) + ":" + String(seconds % 60).padStart(2, "0")
    }
}
