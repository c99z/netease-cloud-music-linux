pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtMultimedia

Rectangle {
    id: bar
    required property Library library
    property bool queueVisible: false
    property bool nowPlayingVisible: false
    signal queueRequested()
    signal nowPlayingRequested()
    signal loginRequested()
    readonly property bool playing: library.media.playbackState === MediaPlayer.PlayingState
                                    && !library.playbackBusy && library.playbackError.length === 0
    readonly property bool hasTrack: library.queueIndex >= 0
    readonly property real duration: library.playbackDuration || library.currentTrack.duration || 0

    color: Theme.rail
    implicitHeight: 92
    Rectangle { width: parent.width; height: 1; color: Theme.line }

    component PlayerSlider: Slider {
        id: slider
        property bool segmented: false
        property var bufferedRegions: []
        property real playedFraction: position
        hoverEnabled: true
        focusPolicy: Qt.StrongFocus
        implicitHeight: 20
        background: Rectangle {
            id: rail
            x: slider.leftPadding
            y: slider.topPadding + (slider.availableHeight - height) / 2
            width: slider.availableWidth
            height: 4
            radius: 2
            color: Theme.line
            Rectangle {
                visible: !slider.segmented
                width: slider.visualPosition * parent.width
                height: parent.height
                radius: 2
                color: slider.enabled ? Theme.accent : Theme.muted
            }
            Repeater {
                model: slider.bufferedRegions
                delegate: Rectangle {
                    id: segment
                    required property var modelData
                    readonly property real start: modelData.start
                    x: rail.width * (slider.mirrored ? 1 - modelData.end : start)
                    width: rail.width * (modelData.end - start)
                    height: rail.height
                    radius: Math.min(rail.radius, width / 2)
                    color: Theme.bufferedAudio
                    Rectangle {
                        width: Math.min(segment.width, rail.width * Math.max(0, slider.playedFraction - segment.start))
                        x: slider.mirrored ? segment.width - width : 0
                        height: segment.height
                        radius: Math.min(segment.radius, width / 2)
                        color: Theme.accent
                    }
                }
            }
        }
        handle: Rectangle {
            x: slider.leftPadding + slider.visualPosition * (slider.availableWidth - width)
            y: slider.topPadding + (slider.availableHeight - height) / 2
            width: slider.pressed || slider.activeFocus ? 12 : slider.hovered ? 9 : 6
            height: width
            radius: width / 2
            color: slider.enabled || slider.segmented ? Theme.accent : Theme.muted
            visible: slider.segmented ? bar.hasTrack && bar.duration > 0
                   : slider.enabled && (slider.hovered || slider.activeFocus || slider.pressed)
        }
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 22
        anchors.rightMargin: 22
        spacing: 20
        AbstractButton {
            id: trackButton
            Layout.preferredWidth: 250
            Layout.minimumWidth: 146
            Layout.maximumWidth: 300
            Layout.fillWidth: true
            Layout.leftMargin: -8
            padding: 8
            hoverEnabled: true
            enabled: bar.hasTrack
            focusPolicy: Qt.StrongFocus
            Accessible.name: (bar.nowPlayingVisible ? "收起播放页：" : "打开播放页：")
                             + (bar.library.currentTrack.title || "")
            onClicked: bar.nowPlayingRequested()
            ToolTip.visible: hovered && enabled
            ToolTip.delay: 500
            ToolTip.text: bar.nowPlayingVisible ? "收起播放页" : "打开播放页"
            background: Rectangle {
                radius: 10
                color: bar.nowPlayingVisible ? Theme.accentSurface
                     : trackButton.hovered || trackButton.down ? Theme.hover : "transparent"
                border.color: trackButton.activeFocus ? Theme.accent : "transparent"
            }
            contentItem: RowLayout {
                spacing: 12
                Cover {
                    Layout.preferredWidth: 52
                    Layout.preferredHeight: 52
                    source: bar.library.currentTrack.art || ""
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 1
                    Label {
                        Layout.fillWidth: true
                        text: bar.library.currentTrack.title || "尚未播放"
                        textFormat: Text.PlainText
                        color: Theme.text
                        font.pixelSize: 14
                        font.weight: Font.Bold
                        elide: Text.ElideRight
                    }
                    Label {
                        Layout.fillWidth: true
                        text: bar.library.playbackBusy || bar.library.media.mediaStatus === MediaPlayer.StalledMedia
                               ? "正在缓冲音频…"
                             : bar.library.preview ? (bar.library.currentTrack.artist || "") + "  ·  试听"
                             : bar.library.currentTrack.artist || "从歌单或搜索结果选择一首歌"
                        textFormat: Text.PlainText
                        color: Theme.secondary
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }
                }
                Symbol {
                    Layout.preferredWidth: 14
                    Layout.preferredHeight: 14
                    name: bar.nowPlayingVisible ? "down" : "up"
                    tint: bar.nowPlayingVisible || trackButton.hovered ? Theme.accent : Theme.muted
                    visible: bar.hasTrack
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.preferredWidth: 400
            Layout.maximumWidth: 560
            spacing: 0
            RowLayout {
                Layout.alignment: Qt.AlignHCenter
                spacing: 10
                IconButton {
                    symbol: "previous"
                    text: "上一首"
                    enabled: bar.library.queueIndex > 0 || bar.library.canSeekPlayback
                    onClicked: bar.library.previous()
                }
                IconButton {
                    symbol: bar.playing ? "pause" : "play"
                    text: bar.playing ? "暂停" : bar.library.playbackError.length ? "重试播放"
                         : bar.hasTrack ? "播放" : "播放新歌推荐"
                    featured: true
                    iconSize: 21
                    enabled: !bar.library.playbackBusy && (bar.hasTrack || bar.library.freshTracks.length > 0)
                    onClicked: bar.library.togglePlayback()
                }
                IconButton {
                    symbol: "next"
                    text: "下一首"
                    enabled: bar.library.queueIndex + 1 < bar.library.queue.length || (bar.library.roamPlaying && !bar.library.playbackBusy)
                    onClicked: bar.library.next()
                }
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: 6
                Label {
                    Layout.preferredWidth: 38
                    text: Theme.time(progress.pressed ? progress.value : bar.library.playbackPosition)
                    horizontalAlignment: Text.AlignRight
                    color: Theme.muted
                    font.pixelSize: 11
                }
                PlayerSlider {
                    id: progress
                    property real pendingSeek: 0
                    segmented: true
                    bufferedRegions: bar.library.bufferedRanges
                    playedFraction: bar.duration > 0 ? bar.library.playbackPosition / bar.duration : 0
                    Layout.fillWidth: true
                    from: 0
                    to: Math.max(1, bar.duration)
                    enabled: !bar.library.playbackBusy && bar.library.canSeekPlayback && bar.duration > 0
                    Accessible.name: "播放进度"
                    Binding on value {
                        value: bar.library.playbackPosition
                        when: !progress.pressed
                        restoreMode: Binding.RestoreNone
                    }
                    onMoved: {
                        if (pressed)
                            pendingSeek = value
                        else
                            bar.library.seekPlayback(value)
                    }
                    onPressedChanged: {
                        if (pressed)
                            pendingSeek = value
                        else if (enabled)
                            bar.library.seekPlayback(pendingSeek)
                    }
                }
                Label {
                    Layout.preferredWidth: 38
                    text: Theme.time(bar.duration)
                    color: Theme.muted
                    font.pixelSize: 11
                }
            }
        }

        RowLayout {
            Layout.preferredWidth: 251
            Layout.minimumWidth: 150
            Layout.maximumWidth: 255
            Layout.fillWidth: true
            spacing: 4
            Item { Layout.fillWidth: true }
            IconButton {
                symbol: "heart"
                text: bar.library.currentLiked ? "取消喜欢" : "喜欢"
                selected: bar.library.currentLiked
                enabled: bar.hasTrack
                onClicked: {
                    if (bar.library.loggedIn)
                        bar.library.toggleLike()
                    else
                        bar.loginRequested()
                }
            }
            IconButton {
                symbol: "trash"
                text: "漫游 · 不喜欢"
                visible: bar.library.roamPlaying
                enabled: bar.hasTrack && !bar.library.playbackBusy
                onClicked: bar.library.dislikeRoamTrack()
            }
            IconButton {
                symbol: bar.library.audio.muted || bar.library.audio.volume === 0 ? "muted" : "volume"
                text: bar.library.audio.muted || bar.library.audio.volume === 0 ? "恢复声音" : "静音"
                onClicked: bar.library.toggleMute()
            }
            PlayerSlider {
                Layout.preferredWidth: bar.width >= 1000 ? 91 : 56
                from: 0
                to: 1
                value: bar.library.audio.volume
                Accessible.name: "音量"
                onMoved: {
                    bar.library.audio.volume = value
                    bar.library.audio.muted = false
                }
            }
            IconButton {
                symbol: "output"
                text: "音频设置 · " + bar.library.outputName
                selected: outputChooser.opened
                onClicked: outputChooser.open()
            }
            IconButton {
                symbol: "queue"
                text: "播放队列"
                selected: bar.queueVisible
                onClicked: bar.queueRequested()
            }
        }
    }
    component AudioDeviceButton: AudioActionButton {
        required property string deviceId
        selected: bar.library.outputId === deviceId
        onClicked: {
            bar.library.selectOutput(deviceId)
            outputChooser.close()
        }
    }

    component AudioActionButton: Button {
        id: deviceButton
        property bool selected: false
        Layout.fillWidth: true
        contentItem: Label {
            text: deviceButton.text
            color: !deviceButton.enabled ? Theme.muted : deviceButton.selected ? Theme.text : Theme.secondary
            elide: Text.ElideRight
            verticalAlignment: Text.AlignVCenter
            font.pixelSize: 12
        }
        background: Rectangle {
            implicitHeight: 34
            radius: 7
            color: deviceButton.selected ? Theme.accentSurface
                 : deviceButton.hovered ? Theme.hover : Theme.raised
            border.color: deviceButton.activeFocus ? Theme.accent : "transparent"
        }
    }

    Popup {
        id: outputChooser
        x: bar.width - width - 20
        y: -height - 6
        width: 310
        padding: 12
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
        background: Rectangle {
            color: Theme.panel
            radius: 11
            border.color: Theme.line
        }
        contentItem: ColumnLayout {
            spacing: 5
            Label {
                Layout.fillWidth: true
                Layout.bottomMargin: 5
                text: "音频输出"
                color: Theme.text
                font.bold: true
            }
            AudioDeviceButton {
                deviceId: ""
                text: "跟随系统默认"
            }
            Repeater {
                model: bar.library.outputDevices
                delegate: AudioDeviceButton {
                    required property var modelData
                    deviceId: modelData.id
                    text: modelData.label
                }
            }
            Rectangle {
                Layout.fillWidth: true
                Layout.topMargin: 5
                Layout.bottomMargin: 3
                Layout.preferredHeight: 1
                color: Theme.line
            }
            AudioActionButton {
                text: "切换音源"
                enabled: bar.hasTrack && !bar.library.playbackBusy
                onClicked: {
                    bar.library.switchAudioStream()
                    outputChooser.close()
                }
            }
        }
    }

}
