pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

GridLayout {
    id: strip
    required property var charts
    signal chosen(var chart)
    columns: width >= 790 ? 3 : width >= 510 ? 2 : 1
    columnSpacing: 12
    rowSpacing: 10

    Repeater {
        model: strip.charts
        delegate: AbstractButton {
            id: card
            required property var modelData
            Layout.fillWidth: true
            Layout.preferredWidth: 1
            Layout.preferredHeight: 132
            padding: 12
            hoverEnabled: true
            focusPolicy: Qt.StrongFocus
            Accessible.name: modelData.title
            onClicked: strip.chosen(modelData)
            background: Rectangle {
                radius: 11
                color: card.hovered ? Theme.raised : Theme.panel
                border.color: card.activeFocus ? Theme.accent : Theme.line
            }
            contentItem: ColumnLayout {
                spacing: 8
                RowLayout {
                    Layout.fillWidth: true
                    Label {
                        Layout.fillWidth: true
                        text: card.modelData.title
                        color: Theme.text
                        font.pixelSize: 17
                        font.weight: Font.Bold
                        elide: Text.ElideRight
                    }
                    Label {
                        text: card.modelData.description
                        color: Theme.muted
                        font.pixelSize: 10
                    }
                }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10
                    Cover {
                        Layout.preferredWidth: 66
                        Layout.preferredHeight: 66
                        source: card.modelData.art
                    }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 4
                        Repeater {
                            model: card.modelData.preview
                            delegate: RowLayout {
                                id: rank
                                required property int index
                                required property var modelData
                                Layout.fillWidth: true
                                spacing: 8
                                Label {
                                    text: rank.index + 1
                                    color: rank.index === 0 ? Theme.accent : Theme.muted
                                    font.pixelSize: 11
                                    font.weight: Font.DemiBold
                                }
                                Label {
                                    Layout.fillWidth: true
                                    text: rank.modelData.title + (rank.modelData.artist ? " · " + rank.modelData.artist : "")
                                    elide: Text.ElideRight
                                    color: Theme.secondary
                                    font.pixelSize: 11
                                }
                            }
                        }
                        Label {
                            visible: card.modelData.preview.length === 0
                            text: "查看榜单"
                            color: Theme.secondary
                            font.pixelSize: 11
                        }
                    }
                }
            }
        }
    }
}
