import QtQuick

Item {
    id: root
    property url source
    property int edge: 7

    Rectangle {
        anchors.fill: parent
        radius: root.edge
        color: Theme.accentSurface
        border.color: Theme.line
        Symbol {
            anchors.centerIn: parent
            name: "music"
            width: Math.min(parent.width * .42, 32)
            height: width
            tint: Theme.accent
            opacity: .65
        }
    }
    Image {
        anchors.fill: parent
        anchors.margins: 1
        source: root.source
        fillMode: Image.PreserveAspectCrop
        horizontalAlignment: Image.AlignHCenter
        verticalAlignment: Image.AlignVCenter
        asynchronous: true
        visible: status === Image.Ready
    }
}
