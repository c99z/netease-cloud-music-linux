#include "Library.h"

#include <QGuiApplication>
#include <QIcon>
#include <QQmlApplicationEngine>
#include <QQuickStyle>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    app.setOrganizationName("RecordRoom");
    app.setApplicationName("RecordRoom");
    app.setApplicationDisplayName(QStringLiteral("网易云音乐"));
    app.setDesktopFileName("local.record-room");
    app.setWindowIcon(QIcon(":/branding/assets/netease-music.png"));
    QQuickStyle::setStyle("Basic");

    Library library;
    QQmlApplicationEngine engine;
    engine.setInitialProperties({{"library", QVariant::fromValue(&library)}});
    engine.loadFromModule("RecordRoom", "Main");
    if (engine.rootObjects().isEmpty())
        return 1;

    library.start();
    return app.exec();
}
